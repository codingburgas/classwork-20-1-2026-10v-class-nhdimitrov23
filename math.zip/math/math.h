#pragma once
int add(int, int);
int subtract(int, int);
int multiply(int, int);
int divide(int, int);